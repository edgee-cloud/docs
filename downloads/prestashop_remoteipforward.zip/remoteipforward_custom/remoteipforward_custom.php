<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

class remoteipforward_custom extends Module
{
    public function __construct()
    {
        $this->name = 'remoteipforward_custom';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Edgee(edgee.cloud)';
        $this->need_instance = 0;

        parent::__construct();

        $this->displayName = $this->l('Remote IP Forward Override');
        $this->description = $this->l('Overrides client IP detection using X-Forwarded-For.');
    }

    public function install()
    {
        return parent::install() &&
               $this->registerHook('actionFrontControllerInitBefore');
    }

    public function hookActionFrontControllerInitBefore($params)
    {
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $forwardedIps = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $ip = trim($forwardedIps[0]);

            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                $_SERVER['REMOTE_ADDR'] = $ip;
            }
        }
    }
}
